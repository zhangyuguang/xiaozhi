﻿<?php 
require_once("./mydb.php");
$db = new DB();

header("Content-type: text/html; charset=utf-8");  
//$st_info=iconv("UTF-8","gb2312",$_POST["st_info"]); 
$st_info=$_POST['st_info'];
$st_addr=$_POST['st_addr'];
$st_type=$_POST['st_type'];
$off_info=$_POST['off_info'];
$item_info=$_POST['item_info'];
$item_type=$_POST['item_type'];
$exdate=$_POST['exdate'];
	
//$rstr="1:".$st_info."2:".$st_addr."3:".$st_type."4:".$off_info."5:".$item_info."6:".$item_type."7:".$exdate;

$sql = "Insert Into `info` Values (NULL, '".$st_info."', '".$st_addr."', '".$st_type."', '".$off_info."', '".$item_info."', '".$item_type."', '".$exdate."')";
		//$db->write_log($sql);
if ($db->query($sql)) echo json_encode("1");
else json_encode("0");
//$queryStr = json_decode($postStr);
//echo json_encode($rstr); 

?>