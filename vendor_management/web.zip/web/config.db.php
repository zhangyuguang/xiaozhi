﻿<?php 
	$db_config["hostname"] = "localhost";	//服务器地址
	$db_config["username"] = "root";	//数据库用户名
	$db_config["password"] = "openair";		//数据库密码
	$db_config["database"] = "vendor";		//数据库名称
	$db_config["charset"] = "utf8";			//数据库编码
	$db_config["pconnect"] = 1;				//开启持久连接
	$db_config["debug"] = 1;				//输出调试信息
	$db_config["log"] = 0;					//开启日志
	$db_config["logfilepath"] = './';		//日志所在目录
?>